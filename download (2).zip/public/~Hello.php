<?php
    print("Hello PHP");