'''
OpenCVを利用した画像検出です。

https://opencv.org/

人物画像から目を検出します。
#pyscript
'''
import matplotlib.pyplot as plt
import cv2
from PIL import Image
import requests
import io
import os
import numpy as np
#ネットワークエラー対策
import pyodide_http
pyodide_http.patch_all()

 #OpenCVで用意されている学習済みカスケード分類器のベースURLです。
url_base_xml="https://raw.githubusercontent.com/opencv/opencv/master/data/"
 #OpenCVで用意されているテスト用データのベースURLです。
url_base_img="https://raw.githubusercontent.com/opencv/opencv/master/samples/data/"

#メイン処理
def main():
    cascade =  "haarcascades/haarcascade_eye.xml" # 目を検出させるカスケード分類器
    img_name = "lena.jpg" # 対象画像

    #カスケード分類器を取得
    filename = get_xml(cascade)
    cascade = cv2.CascadeClassifier(filename)

    #対象画像を取得
    ret = get_img(img_name)
    img = np.array(ret) #numpy配列型に変換
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #グレーにして検出率をあげる

    #検出処理
    eye = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(30, 30))
    plt.clf()
    for (x,y,w,h) in eye: # 検出場所(横、縦、幅、高さ)へ四角形を描画
      img = cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),3)
 
    fig = plt.figure()
    ax = fig.add_axes((0, 0, 1, 1))
    ax.axes.xaxis.set_visible(False)
    ax.axes.yaxis.set_visible(False)
    plt.imshow(img,aspect=0.75)
 
    display(plt,target="G_02") # PyScriptで画像表示する命令。G_XXX・・　　XXX・・は自由に命名

#カスケード分類器を取得
def get_xml(cascade):
  res = requests.get(url_base_xml+cascade)
  name = os.path.basename(cascade)
  with open(name, mode='w') as f:
    f.write(res.text)
  return name

#検出用画像を取得
def get_img(img_name):
  res = requests.get(url_base_img+img_name)
  data = io.BytesIO(res.content)
  img = Image.open(data)
  display(img,target="G_01") # PyScriptで画像表示する命令。G_XXX・・　　XXX・・は自由に命名
  return img

main()

  
