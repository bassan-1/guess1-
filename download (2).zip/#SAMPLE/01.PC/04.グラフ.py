'''
seabornを利用したグラフ作成です。

https://seaborn.pydata.org/index.html
#pyscript

'''

import matplotlib.pyplot as plt
import seaborn as sns
import pyodide_http # ネットワークエラー対応
pyodide_http.patch_all() # ネットワークエラー対応

plt.clf() # 前回描画のクリア
plt.rcParams['font.family'] = 'WebSubsetFont' # 日本語対応のフォント

dots = sns.load_dataset("dots")

sns.relplot(
    data=dots, kind="line",
    x="time", y="firing_rate", col="align",
    hue="choice", size="coherence", style="choice",
    facet_kws=dict(sharex=False),
)

plt.suptitle("グラフ")
#plt.show()
display(plt,target="KEYWORD") # targetは適当なキーワード
# キーワードには英数字、ハイフン、漢字が使えます。
# キーワードの先頭文字に数字、ハイフンは使えません。



