'''
scikit-learnを利用したニューラルネットワークモデルでの機械学習です。

https://scikit-learn.org/stable/

(1)learning
・scikit-learnで用意されている手書数字と正解を取得
・取得したデータの7割を利用して機械学習を行う
・残り3割のデータで検証

さらに精度を確認するため自作手書データ(画面左側クラウドドライブにアップロード済み）で実行
(2)create_my_img
  自作手書き画像をクラウドドライブから取得

(3)perform_my_img
  上記学習済みモデルを使い、自作手書画像から数値を認識。
  ※結果：画像上の数値が認識された数値
#pyscript
'''
import sys
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import load_digits
import matplotlib.pyplot as plt
from PIL import Image, ImageOps
from pywebio import pywebio

#メイン処理
def main():
  #データ取得／機械学習／検証
  clf = learning()
  #自作手書きデータ取得
  testimgs = create_my_img()
  #自作手書きデータを学習済みモデルで検証
  perform_my_img(clf,testimgs)
  clf = None
  testimgs = None

#データ取得／機械学習／検証
def learning():
  digits = load_digits()
  data = digits.data 
  print("全データ数="+str(len(digits.data)))
  target = digits.target 
  #学習用と検証用に分割
  X_train, X_test, y_train, y_test = train_test_split(data, target,
  test_size=0.3) 
  #ニューラルネットワーク作成
  clf = MLPClassifier(hidden_layer_sizes=(256,128))
  #学習開始
  clf.fit(X_train, y_train) 
  #テストデータで検証
  print("テストデータ正解率="+str(clf.score(X_test,y_test))) 
  return clf

 #自作データ取得
def create_my_img():
  TEST_IMG = ["zero","one","two","three","four","five","six","seven","eight","nine"]
  testimgs = np.zeros((10, 64))
  for index,name in enumerate(TEST_IMG):
    data = pywebio.fetch_img("/#SAMPLE/01.PC/data/自作手書数字/"+name+".jpg")
    if data == None: 
      print(name)
      sys.exit()
    #学習画像に合わせるため加工
    data =  ImageOps.invert(data) # 白黒反転
    data = data.convert(mode="L") # 階調を8bitに落とす
    data = np.array(data)        
    testimg =  data // 16  # さらに階調を4bitに落とすため16で除算(手法として不確かです)
    testimgs[index] = testimg.reshape(-1) # データを一次元配列

  #plt.clf()
  #plt.imshow(testimgs[0].reshape(8,8))
  #print(testimgs[0].reshape(8,8))
  #display(plt,target="GRAPH2")  
  return testimgs

##自作手書きデータを学習済みモデルで検証
def perform_my_img(clf,testimgs):
  #データを認識させる
  pred = clf.predict(testimgs)
  plt.clf()  
  fig, ax = plt.subplots(1, 10)
  seikai = 0
  #手書き画像を表示し、タイトルに認識された数値を表示
  for index,img in enumerate(testimgs):
    ax.ravel()[index].imshow(np.reshape(img, (8,8)), cmap=plt.cm.gray_r, interpolation='nearest')
    ax.ravel()[index].set_title(str(pred[index])) # pred[index]認識した数値
    ax.ravel()[index].axes.xaxis.set_visible(False)
    ax.ravel()[index].axes.yaxis.set_visible(False)
    if index == pred[index]: seikai += 1
  plt.show()

  print("自作手書き画像正解率="+str(seikai/10)) 
  display(fig,target="G_01") # PyScriptで画像表示する命令。G_XXX・・　　XXX・・は自由に命名
  plt.clf()
  plt.close()

main()

