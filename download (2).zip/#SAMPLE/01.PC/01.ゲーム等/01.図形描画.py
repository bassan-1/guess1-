'''
図形描画のサンプルです。

命令の詳細は「!Tutorial/Z0.pywab2d/仕様」を確認するか、
命令をダブルクリックすると「PyWebライブラリ」が表示されるので、
選択してください。詳細情報が表示されます。

例)
py.display.init   なら「display」又は「init」をダブルクリック

'''
from pyweb2d import pyweb2d as py
import math
#pyscript

#ウィンドウ作成
sc = py.display.init(640,480)

#ウィンドウのタイトル設定。
py.display.set_caption("図形描画")

#線描画
py.draw.line(sc,"red",(0,0),(639,479),5)

#四角形描画
py.draw.rect(sc,"rgb(100, 58, 58)",(30,30,50,50))

#円描画
py.draw.circle(sc,"#FFFFFFA0", (320,240), 100)

#四角形に内接する楕円を描画
py.draw.ellipse(sc,"pink",(30,30,50,50), 1)

#多角形描画
py.draw.polygon(sc,"blue", ((100, 100), (0, 200), (200, 200)), 3)

#四角形に内接する楕円の孤となる曲線を描画
py.draw.arc(sc, "yellow", (210, 75, 150, 125),  0, math.pi*1.25 , 5)

#フォント指定
py.font.set(sc,"bold 48px serif")

#文字を描画
word = "日本代表"
py.draw.text(sc,"red",word,(500,100),100)

#文字幅取得
width = py.font.get_width(sc,word)
print("文字幅="+str(width))

#文字の高さ取得
height =py.font.get_height(sc,word)
print("文字高="+str(height))

