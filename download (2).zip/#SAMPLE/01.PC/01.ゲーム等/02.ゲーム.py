'''
ブロックをボールで破壊するゲームです。
PyScript上のゲームライブラリpyweb2dで実現しています。

命令の詳細は「!Tutorial/Z0.pywab2d/仕様」を確認するか、
命令をダブルクリックすると「PyWebライブラリ」が表示されるので、
選択してください。詳細情報が表示されます。

例)
py.display.init()  なら「display」又は「init」をダブルクリック

'''
#pyscript
import asyncio
from pyweb2d import pyweb2d as py
import random
import traceback
from pywebio import pywebio


DISPLAY_WIDTH ,DISPLAY_HEIGHT = 640,480
PLAYER_WIDTH,PLAYER_HEIGHT = 100,20
PLAYER_SPEED = 8
PLAYER_YOHAKU = 10

BLOCK_YOKO,BLOCK_TATE,block_width,BLOCK_HEIGHT = 10,5,None,20
BLOCK_YOHAKU_YOKO = 10
BLOCK_YOHAKU_TATE = 10
BLOCK_YOHAKU_TATE_TOP = 30
COLOR_DOUBLE_SCORE = 2 # red
BLOCK_COLORS = ["green","yellow","red","pink","Silver"]

#ブロック情報：カラーインデックス、破壊されたら点数が設定される
blocks = [[0 for j in range(0,BLOCK_YOKO)]   for i in range(0,BLOCK_TATE)]
blocks_score_time = [] # ブロック上に点数を表示する間隔用エリア
OFF = len(BLOCK_COLORS)
OFF2 = OFF + 10 #　ブロック上に点数を表示する間隔

MSG1 = "Press ENTER Key"
MSG2 = "Move Key　←　→"
TEXT_YOHAKU_WIDTH = 60
TEXT_YOHAKU_HEIGHT = 30
TEXT_LINE_YOHAKU = 10

BALL_SIZE = 10
BALL_SPEED_LIMIT_MIN,BALL_SPEED_LIMIT_MAX = 6,10 #ボールスピードの最小、最大
ball_speed = BALL_SPEED_LIMIT_MIN
BALL_SPEED_UP,BALL_SPEDD_DOWN = 1.1,0.9 #ボールスピードの加速、減速率
BALL_START_Y = (BLOCK_HEIGHT + BLOCK_YOHAKU_TATE  ) * BLOCK_TATE + BLOCK_YOHAKU_TATE_TOP + BALL_SIZE # ボールの縦初期位置

ball_x = ball_y = None
ball_houkou = 1

player_x = player_y = None
player_left = player_right = False

rensa = 1; # 連鎖回数　点がこの数値で除算される

#ブロックの状態
UP,UP_LEFT,UP_RIGHT,DWN,DWN_LEFT,DWN_RIGHT = 0,1,2,3,4,5
BALL_HOUKOU_DATA = [[0,-2],[1,-1],[-1,-1],[0,2],[1,1],[-1,1]]

screen = None
score_best = [0,0,0]
SCORE_COLOR = ["Gold","Silver","Saddlebrown"]
SCORE_ONE = 10 # ブロック破壊時の点数
SCORE_DOUBLE = 20 #特定色破壊時の特別ボーナス
score = 0

LIFE_MARK = "🌝"
LIFE_TIME = 3
life = 3

ST_OPEN,ST_START,ST_PLAY = 1,2,3
status = ST_OPEN

font_height = None

# 初期処理
def init():
    global screen,block_width,blocks,blocks_score_time,\
                               font_height,score_best,score,life
    
    # ディスプレイの初期化(必須)
    screen = py.display.init(DISPLAY_WIDTH,DISPLAY_HEIGHT)
    py.display.set_caption("Block Breaker")
    
    width = DISPLAY_WIDTH - BLOCK_YOHAKU_YOKO * 11
    block_width = width // BLOCK_YOKO # 画面サイズからブロックの幅を決定
    
    for idx,block in enumerate(blocks): # ブロックの色決定
        for idx2,b in enumerate(block):
          blocks[idx][idx2] = random.randrange(len(BLOCK_COLORS))
          
    blocks_score_time = [[0 for j in range(0,BLOCK_YOKO)]  \
                                     for i in range(0,BLOCK_TATE)]
    score = 0
    life = LIFE_TIME
    py.font.set(screen,"bold 16px 'Times New Roman'")
    font_height = py.font.get_height(screen,MSG1)
    data = pywebio.fetch("/#SAMPLE/01.PC/data/score.txt")
    
    if data != None and data != "":
        data = data.split(',')
        score_best = [int(value) for value in data]
    
#　開始処理
def start():
    global ball_x,ball_y,ball_houkou,player_x,player_y,rensa,ball_speed
    # プレイヤーの初期位置
    player_x = DISPLAY_WIDTH/2-PLAYER_WIDTH/2
    player_y = DISPLAY_HEIGHT - PLAYER_HEIGHT - PLAYER_YOHAKU
    # ボールの初期位置、方向、スピード、連鎖初期化
    ball_x = DISPLAY_WIDTH/2 - BALL_SIZE /2
    ball_y = BALL_START_Y
    ball_houkou = random.randrange(3) + 3
    rensa = 1
    ball_speed = BALL_SPEED_LIMIT_MIN

#ゲーム開始画面の描画
def draw_open():
    #メッセージ表示
    width = py.font.get_width(screen,MSG1) # メッセージの横サイズ
    x = DISPLAY_WIDTH / 2 - width/ 2 - TEXT_YOHAKU_WIDTH
    y = DISPLAY_HEIGHT / 3  - font_height/ 2 - TEXT_YOHAKU_WIDTH
    width2 = width + TEXT_YOHAKU_WIDTH * 2
    height2 = (font_height + TEXT_LINE_YOHAKU) * 5.5 + TEXT_YOHAKU_HEIGHT * 2
    py.draw.rect(screen,"#778899F0",(x,y,width2,height2)) #背景描画
    y += font_height + TEXT_YOHAKU_HEIGHT
    py.draw.text(screen,"blue",MSG1,(x+TEXT_YOHAKU_WIDTH,y),width2)
    
    #キー操作メッセージ表示
    y += font_height + TEXT_LINE_YOHAKU
    width = py.font.get_width(screen,MSG2)
    x = DISPLAY_WIDTH / 2 - width/ 2
    py.draw.text(screen,"black",MSG2,(x,y),width2)
  
    #ランキングスコアー表示 
    y += font_height + TEXT_LINE_YOHAKU * 1.5
    width = py.font.get_width(screen,"1:00000")
    x = DISPLAY_WIDTH / 2 - width/ 2 
    for idx,s in enumerate(score_best):
        line = str(idx+1)+". " + f"{s:05}"
        py.draw.text(screen,SCORE_COLOR[idx], line,(x,y))
        y += font_height + TEXT_LINE_YOHAKU

#描画処理
def draw():
    global blocks,blocks_score_time
  
    py.draw.clear(screen) # 全画面クリア
  
    #ブロック
    for idx,block in enumerate(blocks):
        for idx2,colorid in enumerate(block):
            y = idx * BLOCK_HEIGHT + (idx+1) * \
                            BLOCK_YOHAKU_TATE + BLOCK_YOHAKU_TATE_TOP
            x = idx2 * block_width + (idx2+1) * BLOCK_YOHAKU_YOKO
            if blocks[idx][idx2] < OFF:
                color = BLOCK_COLORS[colorid]
                py.draw.rect(screen,color,(x,y,block_width,BLOCK_HEIGHT))
            elif  blocks_score_time[idx][idx2] < OFF2: # ブロック位置に点表示
                width = py.font.get_width(screen,str(blocks[idx][idx2]))
                x += (block_width - width) / 2
                y +=  BLOCK_HEIGHT - (font_height/2)
                py.draw.text(screen,"white",str(blocks[idx][idx2]),\
                                                         (x,y),block_width)
                blocks_score_time[idx][idx2] += 1
        
    # ボール     
    py.draw.circle(screen,"white", (ball_x,ball_y), BALL_SIZE, width=0)
    # Player
    py.draw.rect(screen,"blue",(player_x,player_y,PLAYER_WIDTH,PLAYER_HEIGHT))
    # スコアー
    py.font.set(screen,"16px 'Times New Roman'")
    py.draw.text(screen,"white","SCORE:",(530,font_height),50)
    py.draw.text(screen,"white", f'{score:05}',(580,font_height),50)
    #ライフ
    text = LIFE_MARK * life 
    py.draw.text(screen,"white",text,(1,font_height))
    
#プレイヤー移動
def move_player():
    global player_x,player_left,player_right

    if player_right: # 左矢印が押されている
        player_x += PLAYER_SPEED
        if player_x + PLAYER_WIDTH > DISPLAY_WIDTH: player_x -= PLAYER_SPEED

    if player_left: # 右矢印が押されている
        player_x -= PLAYER_SPEED
        if player_x  < 0: player_x = 0

# ボール移動
def move_ball():
    global ball_x,ball_y
    
    ball_x += BALL_HOUKOU_DATA[ball_houkou][0] * ball_speed / 2
    ball_y +=  BALL_HOUKOU_DATA[ball_houkou][1]  * ball_speed / 2

#衝突判定
def collision_judge():
    global life,status,rensa,ball_houkou,ball_speed

    # ブロックとボール
    for idx,block in enumerate(blocks):
        y = idx * BLOCK_HEIGHT + (idx+1) * BLOCK_YOHAKU_TATE +\
                                                BLOCK_YOHAKU_TATE_TOP
        for idx2,color in enumerate(block):
            if blocks[idx][idx2] < OFF:
                x = idx2 * block_width + (idx2+1) * BLOCK_YOHAKU_YOKO
                if collision(ball_x-BALL_SIZE/2,\
                             ball_y-BALL_SIZE/2,BALL_SIZE,BALL_SIZE,\
                                                x,y,block_width,BLOCK_HEIGHT):
                    
                    collision_block(idx,idx2) # ブロック衝突処理
                    break
                    
    # プレイヤーとボール
    width = PLAYER_WIDTH // 3
    p_x = player_x
    for i in [2,0,1]: # プレイヤー(パドル)の左、中、右側で判定する
        if collision_player_ball(p_x,width):
            ball_houkou = i # 衝突した場所によりボールの方向を決定
            rensa = 1
            break
        p_x += width

    # ボールと横枠
    if ball_x - BALL_SIZE < 0 or ball_x + BALL_SIZE > DISPLAY_WIDTH:
        rensa = 1
        ball_speed *= BALL_SPEDD_DOWN
        if ball_speed < BALL_SPEED_LIMIT_MIN: ball_speed = BALL_SPEED_LIMIT_MIN
        ball_houkou += 1
        if 0 == ball_houkou % 3: ball_houkou -= 2 #ボールの方向を逆転させる

  # ボールが上下枠を超えた？
    if (ball_y+BALL_SIZE/2) <= 0 or (ball_y-BALL_SIZE/2) > DISPLAY_HEIGHT:
        life -= 1
        status = ST_START

#プレイヤーの左、中、右側とボールの衝突判定
def collision_player_ball(p_x,width):
  if collision(p_x,player_y,width,PLAYER_HEIGHT,\
                ball_x-BALL_SIZE/2,ball_y+BALL_SIZE/2, BALL_SIZE,BALL_SIZE) :
      return True

  return False

#ブロック破壊処理  
def collision_block(idx,idx2):
    global blocks,score,rensa,ball_houkou,ball_speed

    tmp_ten = SCORE_ONE
    # 特定色は点が倍
    if blocks[idx][idx2] == COLOR_DOUBLE_SCORE:\
                                        tmp_ten = SCORE_DOUBLE
    tmp_score = tmp_ten * rensa
    score += tmp_score
    blocks[idx][idx2] = tmp_score # ブロック表示エリアに点表示
    rensa += 1  #連鎖カウントアップ          
    ball_speed *= BALL_SPEED_UP #ブロックにあたるとボールの速度アップ
    if ball_speed > BALL_SPEED_LIMIT_MAX:\
                            ball_speed = BALL_SPEED_LIMIT_MAX
    if ball_houkou > UP_RIGHT: # ボールを反転させる
        ball_houkou -= 3
    else:
        ball_houkou += 3


#衝突判定コア処理
def collision(x1,y1,w1,h1,x2,y2,w2,h2):
    if ((x1-w2)<= x2) and (x2 <= (x1+w1)) and \
     ((y1-h2)<= y2) and (y2 <= (y1+h1)) :
        return True
   
    return False

#メインループ
def main_loop(e):
    global player_left,player_right,status,score_best
  
    try:
        draw() # 描画処理
        #ゲーム開始前ならオープニングメッセージを描画
        if status == ST_OPEN:
            draw_open()

        events = py.event.get() # イベント(キー押下、マウス操作など)情報取得
        
        # イベント情報分ループする
        for event in events:
            player_left = False
            player_right = False
            if status == ST_PLAY: #プレイ中ならキー判定する
                if event.type == "keydown":
                    # 左矢印押されている 
                    if event.key == "ArrowRight": player_right = True  
                    # 右矢印が押されている
                    if event.key == "ArrowLeft": player_left = True  
            
            elif status == ST_OPEN: # ゲーム開始前
                # ENTERキーが押された
                if event.type == "keydown" and event.key == "Enter": 
                    init()
                    status = ST_PLAY
            
            if event.type == py.QUIT: # ウィンド閉じるボタンで終了
                py._quit() # 終了処理 必須
                return # 記述必須
  
        if status == ST_PLAY: # プレイ中なら各処理を呼出す
            move_player() # プレイヤー移動
            move_ball()   # ボール移動
            collision_judge() # 衝突反転
            
        if status == ST_START:
            if life == 0: # ライフがなくなったのでゲーム終了
                status = ST_OPEN
                start()
                
                score_best.append(score)
                score_best.sort(reverse=True)
                del score_best[len(score_best)-1]
                data = ','.join(map(str, score_best))
                pywebio.put("/#SAMPLE/01.PC/data/score.txt",data)   
                
            else:
                start()
                status = ST_PLAY


        '''
        メインループを一定間隔で呼出すための設定。
        メインループの最後に記述必須.
        引数の「main_loop」は自身の関数名を書く
        '''
        py.loop_set(main_loop)
      
    except Exception as e: # エラー処理 記述必須
        py._quit()
        print(traceback.format_exc())  
   

#メイン処理
async def main(): # async必須
    init()  # 初期処理
    start() # ゲームスタート処理
    main_loop("EVENT") # メインループ呼び出し(引数設定必要）
    
asyncio.ensure_future(main())

