'''
シンプルな足し算問題を提示するゲームです。
PCモードでのINPUT命令の動作を確認してみてください。
#pyscript
'''
import random

print("足し算ゲームスタート")

while(True):
    x = random.randint(1,100)
    x2 = random.randint(1,100)
    
    ans = input(str(x)+"+"+str(x2)+"=? (q:終了)")
    if ans == "q":
        break

    ans = int(ans)

    if (x + x2) == ans:
        print("正解")
    else:
        print("不正解")
