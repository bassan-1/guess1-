'''
ゲーム作成のテンプレートです。
これを利用してゲーム作成に挑戦してみてください。

命令の詳細は「!Tutorial/Z0.pywab2d/仕様」を確認するか、
命令をダブルクリックすると「PyWebライブラリ」が表示されるので、
選択してください。詳細情報が表示されます。

例)
py.display.init()  なら「display」又は「init」をダブルクリック

'''
#pyscript
import asyncio
from pyweb2d import pyweb2d as py
import traceback
import random

WIDTH = 640
HEIGHT = 480
x = y = 0
sc = None
img = None
right = left = up = down = False

# 初期処理
def init():
    global sc
    # ディスプレイの初期化(必須)
    sc = py.display.init(WIDTH,HEIGHT)
    py.display.set_caption("GAME TEMPLATE")
    '''
    ここに初期処理を記述
    '''

# 非同期用初期処理  (image.load,image.openを使わないなら不要)
async def init_async():
    global img
    '''
    awaitを付けて呼出す関数を利用する場合はこちらに記述
         awaitが必要な関数：image.load,image.open
    '''
    #例
    img = await py.image.load("#SAMPLE/01.PC/data/logo.png")

    
#描画処理
def draw():
    '''
    ここに描画処理を記述
    '''
    # 例
    py.draw.clear(sc)
    py.draw.circle(sc,"blue",(y+320,x+240),30,2)
    py.draw.img(sc,img,(x+320-img.width/2,y+240-img.height/2))
    py.font.set(sc,"24px 'Times New Roman'")
    word = "矢印キーを押してください"
    x2 = 320 - py.font.get_width(sc,word)/2
    py.draw.text(sc,"white",word,(x2,50))
    
#移動
def move():
    '''
    ここに移動等の処理等を記述
    '''
    # 例
    global x,y
    if right : x += 3
    if left  : x -= 3
    if up    : y -= 3
    if down  : y += 3
  
#メインループ
def main_loop(dummy):  
    global right,left,up,down
    
    try: #エラー処理(必須)    
        draw() # 描画処理
        events = py.event.get() # イベント取得
        right = left = up = down = False       
        # イベント情報分ループする
        for event in events:
            '''
            ここにイベント時の処理を記述
            '''
            # 例
            if event.type == "keydown":
                if event.key == "ArrowRight": right = True # 左矢印が押されている  
                if event.key == "ArrowLeft": left = True   # 右矢印が押されている
                if event.key == "ArrowUp":up = True        # 上矢印が押されている
                if event.key == "ArrowDown": down = True   # 下矢印が押されている
            if event.type == "mousedown":print(event.button)   
            if event.type == py.QUIT: # ウィンド閉じるボタンで終了
                py._quit() # 終了処理(必須)
                return
            
    
        move() # 移動処理
        '''
        移動以外の処理があれば呼び出す
        ''' 
        

        '''
        メインループを一定間隔で呼出すための設定。
        メインループの最後に記述必須.
        引数の「main_loop」は自身の関数名を書く
        '''
        py.loop_set(main_loop) # 必須

    except Exception as e: #エラー処理(必須)
        py._quit()
        print(traceback.format_exc()) # エラー表示
         
#メイン処理
async def main(): #async 必須
    init()  # 初期処理
    await init_async() # 非同期用初期処理
    main_loop("dummy") # メインループ呼び出し(引数設定必要）

asyncio.ensure_future(main()) #メイン関数(main())呼出し


''' 

event属性

    event.type     :イベントタイプ
                        "keydown"       :キーが押された
                        "keyup"         :キーが離された
                        "mousemove"     :マウスが動かされた
                        "mousedown"     :マウスボタンが押された
                        "mouseup"       :マウスボタンが離された
                        py.QUIT         :ウィンド閉じるボタンが押された

    event.pos[x,y]) :マウスイベント時に発生したX,Y座標。[X座標、Y座標]
    event.button   :マウスイベント時に押されたボタン。１:左ボタン、３：右ボタン
    event.key      :キーイベント時のキー種類。キー種類はJavaScriptと同等
 https://developer.mozilla.org/en-US/docs/Web/API/UI_Events/Keyboard_event_code_values
    

'''
