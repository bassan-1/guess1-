'''
LOGO言語、Python turtleに類似したプログラミング学習用環境「PyKAME」のサンプルです。
小学校高学年以上対象のチュートリアルを「!Tutorial/@はじめてのプログラミング」で提供しています。

'''
#MODE=PC(ayax)
from pykame.pykame import *

# ウィンドウの設定
init_kame()

#多角形描画
def polygon(nagasa,color,n):
    pendown()
    angle = (180 * (n-2))/n
    pencolor(color)
    for i in range(n):
        forward(nagasa)
        left(180 - angle)
    penup()

#線を引く
def line(x,y,l,a,color):
    pensize(10)
    pencolor(color)
    setposition(x,y)
    pendown()
    setheading(a)
    forward(l)
    penup()
    pensize(5)

#メイン描画    
def draw():
    B_X = -280
    B_Y = 50
    speed(5)
    penup()
    pensize(5)
    setposition(B_X,B_Y)
    polygon(100,"#FFCCFF",4) # 四角形
    setposition(B_X+150,B_Y)
    polygon(120,"#3CB371",3) # 三角形
    pencolor("#0066FF")
    setposition(B_X+350,B_Y)
    write("X",align='center',size=136) # X    
    setposition(B_X+550,B_Y+50)
    setheading(90)
    pencolor("#FF69A3")
    pendown()
    circle(60) # 円
    penup()
    pencolor("blue")
    setposition(0,B_Y-150)
    write("～プログラミング学習環境～",align='center',size=16)
    
    pencolor("red")
    setposition(0,B_Y-120)
    write("PyKAME",align='center',size=48)
    penup()
    home()

hideturtle()
penup()
setposition(-320,240)
showturtle()
home()
pendown()
ontimer(draw,1500) #1.5秒後に関数drawを呼出す。












