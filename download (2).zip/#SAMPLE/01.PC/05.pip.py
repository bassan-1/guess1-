'''
外部ライブラリのインストール
・よく利用されるライブラリはimport命令を記述するだけで、自動的にインストールされます。
・import命令でインストールされない場合は、こちらのプログラムを起動しインストールしてください。

注意
・PCモードでは、Pythonがブラウザで動作するため全ての外部ライブラリが正常動作するとは限りません。
　特に、GUI、ネットワーク関連に関しては動作しない可能性が高いです。
・インストールしたライブラリは、PyWebに接続するたびに再度インストールする必要があります。

'''
#MODE=PC(ayax)
import micropip

async def install(module):    
    try:
        await micropip.install(module)
        print(micropip.list())
    except Exception as e:
        print("インストールできませんでした。",module)
    
    
module = input("install name?")
install(module) 
