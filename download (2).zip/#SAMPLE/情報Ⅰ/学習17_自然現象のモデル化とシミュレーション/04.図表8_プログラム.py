'''
画面右上のPCが選択されていない場合は、クリックし選択してください。#MODE=PC(ayax)
'''
import matplotlib.pyplot as plt # グラフ描画ライブラリ
import numpy.random as rd # 乱数のためのライブラリ

plt.clf() # ayax 前回グラウフ削除
x=[0] #X の初期値を 0 にする
y=[0] #Y の初期値を 0 にする
for i in range(1000):
    x.append(x[i]+rd.random() - 0.5) #X 方向
    y.append(y[i]+rd.random() - 0.5) #Y 方向
    
trace = [x, y] #XY 平面状の物体の座標を trace という名前の配列に代入
plt.plot(*trace) # 配列要素のグラフ描画
plt.axis("equal") # グラフの縦横比を等しく
plt.title("random walk") # グラフのタイトルをつける
#plt.show()
#plt.savefig('図表8.png') # ayax ファイルに保存
display(plt,target="図表８") # ayax