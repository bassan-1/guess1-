import numpy.random as rd # 乱数を発生させる関数の呼び出し
ransuu = rd.rand() #0 〜 1 の乱数を 1 個生成
print(" 乱数 ", ransuu) # 乱数の値を表示
