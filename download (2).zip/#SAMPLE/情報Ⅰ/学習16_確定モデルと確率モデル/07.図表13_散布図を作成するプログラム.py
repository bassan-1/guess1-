'''
負荷軽減のため、forの中のプロットをfor終了後に一括してプロットしています。
画面右上のPCが選択されていない場合は、クリックし選択してください。#MODE=PC(ayax)
'''
import numpy.random as rd # 乱数を発生させる関数の呼び出し
import matplotlib.pyplot as plt # グラフプロットの呼び出し

plt.clf() # ayax 前回グラウフ削除
totalcount = 2000 # ランダムに打つ点の総数
incount = 0 # 円に入った点の数

# ayax 一括プロットするためのデータ
in_x_data = []
in_y_data = []
out_x_data = [] 
out_y_data = []

for i in range(totalcount):
    x = rd.random() #0-1 の範囲の値
    y = rd.random() #0-1 の範囲の値
 
    if x**2 + y**2 < 1.0: # 単位円の中に入ったら
         incount += 1 # 入ったカウンターに１を加える
         in_x_data.append(x) # ayax 一括プロットするためデータを格納
         in_y_data.append(y) # ayax 一括プロットするためデータを格納        
    else:
         out_x_data.append(x) # ayax 一括プロットするためデータを格納
         out_y_data.append(y) # ayax 一括プロットするためデータを格納

# 一括プロット
plt.scatter(in_x_data, in_y_data, c="red") # 赤色でプロット
plt.scatter(out_x_data,out_y_data, c="blue") # 青色でプロット

print(" 円周率 :", incount * 4.0 / totalcount) # 求まった円周率
plt.title("Monte Carlo method") # グラフのタイトル
#plt.show()
#plt.savefig('図表13.png') # ayax ファイルに保存
display(plt,target="図表13") # ayx




