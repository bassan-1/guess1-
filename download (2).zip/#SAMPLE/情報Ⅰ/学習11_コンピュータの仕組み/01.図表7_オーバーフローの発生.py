import sys # 変数や関数のライブラリを呼び出し
x=sys.float_info.max #float 型で表せる最大値を x に代入
print(x) # 画面に x の値を表示
x=1.797693134862315799999e+308 #float 型の小数点以下に 5 桁「9」の追加した値を代入
print(x) # 画面に x の値を表示
x=1.8e+308 #float 型の最大値より大きな値を代入
print(x) # 画面に x の値を表示