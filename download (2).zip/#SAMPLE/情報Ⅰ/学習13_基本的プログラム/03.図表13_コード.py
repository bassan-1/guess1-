x = 0
print("x = " , x)
for i in range(1, 6, 1): #1 から 6 未満の間 1 ずつカウントを増やしながら繰り返す
    x = x + 10
    print("x = " , x)