x = 0
print("x = " , x)
for i in range(1, 6, 1):
    x = x + 10
    if i%2==1: #i を 2 で割ったときの余りが 1 のとき
        print("x = " , x)