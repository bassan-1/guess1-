a=[56,3,62,17,87,22,36,83,21,12] # リスト a の定義
goukei = 0
goukei = a[3]+a[7]
print(goukei)