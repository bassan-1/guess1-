a=[56,3,62,17,87,22,36,83,21,12]
goukei = 0
for i in range(0,10,1):
    goukei = goukei+a[i] #a[0] ～ a[9] まで全て加えていく
print(goukei)