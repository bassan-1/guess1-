'''
ayax
requestsモジュールではなく、標準モジュールのrequestを使っています。
従って、パラメータ、呼出し方法等に相違があります。
画面右上のSERVERが選択されていない場合は、クリックし選択してください。#MODE=SERVER(ayax)
'''
from urllib import request # ayax 標準モジュール利用
import json

request_url = "https://zipcloud.ibsnet.co.jp/api/search" # 使用する WebAPI の URL
param = "?zipcode=100-0013" # ayax パラメーターはＵＲＬ形式

response = request.urlopen(request_url+param) # ayax リクエスト発行
response = response.read() # データ取得
response = json.loads(response)

address = response["results"][0]
print(address["address1"] + address["address2"] + address["address3"])