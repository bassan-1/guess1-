import random
r = random.randrange(10)+1
print(r)