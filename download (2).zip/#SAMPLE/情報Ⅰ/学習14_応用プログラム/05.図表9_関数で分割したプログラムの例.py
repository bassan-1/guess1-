def listgoukei(a): # 合計を求める関数 listgoukei を作成
    goukei = 0
    for i in range(0,len(a),1):
        goukei = goukei+a[i]
    return goukei
        
a = [56,3,62,17,87,22,36,83,21,12]
goukei = listgoukei(a) # 作った関数 listgoukei を呼び出し
print(goukei)