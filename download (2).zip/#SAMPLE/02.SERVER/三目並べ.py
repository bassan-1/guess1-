#MODE=SERVER(ayax)
'''
MODE=SERVER(ayax)
コンピュータ対戦型の三目並べです

作成者:ayax
コメント:自分の好みで改造してみてください。終了判定(isEnd())が難しいかもしれませんが、読み解いてみてください。

'''
import random
import sys

KUHAKU = 0
MY = 1	
YOU = 2
#棋盤3X3の配列
kiban = [  [KUHAKU for j in range(0,3)]   for i in range(0,3)]
KIGOU = [" ","X","O"]   #マーク表示用
X = "  a b c"   		#基盤横軸
Y = ["1","2","3"]   	#基盤縦軸
conv = {"a":0,"b":1,"c":2}#横軸を数値へ
kaisu = 0	#回数

def disp(): #棋盤表示
    print("")
    print(X)
    for key1,value1 in enumerate(kiban):
        str = " "
        for key2,value2 in enumerate(value1):
            str += KIGOU[value2] + " "
       	
        str = Y[key1] + str
        print(str)
        
def play(): #人の入力
    global kaisu
    kaisu += 1
    while True:
        print("")
        y = input('1-3,q(終了):')	#縦入力
        if y == 'q':
            sys.exit()
        if y != "1" and y != "2" and y != "3":
            print("1,2,3を入力してください")
            continue
        y = int(y)
        if not y:
            print("入力してください")
            continue
        if  y <1 and y > 3:
            print("範囲外ですー")
            continue
        y -= 1
        x = input('a-c,q(終了):')	#横入力
        if x == 'q':
            sys.exit()
        if not x:
            print("何か打ってよー")          
        if x != 'a' and x != 'b' and x != 'c':
            print("a,b,cを入力してください")
            continue
        #a,b,cを数値に変換
        x = conv[x]
        #既にうたれていないか
        if kiban[y][x] != KUHAKU:
            print("打たれています")
            continue
        kiban[y][x] = YOU    
        break
        
def myPlay():#computer
    global kaisu
    kaisu += 1
    #勝てる場所を探す
    for i in range(0,3):
        for j in range(0,3):
            if kiban[i][j] == KUHAKU:
                kiban[i][j] = MY
                win = isEnd()
                if win:
                    return
                kiban[i][j] = KUHAKU
    #ランダムに打てる場所を探す            
    while(True):
        x = random.randrange(3)    
        y =  random.randrange(3)
        if kiban[y][x] == KUHAKU:
            kiban[y][x] = MY
            break
    return

#終了判定        
def isEnd():
    lines = [ #3つ揃ったか確認するための横、縦、斜めの位置(縦,横)
        [[0,0],[0,1],[0,2]], # 1行目
        [[1,0],[1,1],[1,2]], # 2行目
        [[2,0],[2,1],[2,2]], # 3行目
        [[0,0],[1,0],[2,0]], # 1列目
        [[0,1],[1,1],[2,1]], # 2列目
        [[0,2],[1,2],[2,2]], # 3列目
        [[0,0],[1,1],[2,2]], # 左上から右下の斜め
        [[0,2],[1,1],[2,0]], # 右上から左下の斜め
  ];
    
    for i in lines:# ループしながら指定位置に同じ値が揃っているか確認
        data1 =  kiban[i[0][0]][i[0][1]]
        data2 =  kiban[i[1][0]][i[1][1]]
        data3 =  kiban[i[2][0]][i[2][1]]
        #空白で揃っても意味がないのでチェック
        if data1 == KUHAKU or data2 == KUHAKU or data3 == KUHAKU:
            continue
        #３つとも同じか
        if data1 == data2 and data2 == data3:
            return True
    
    return False


disp()
#メイン処理
while(True):            
    play()
    disp()
    
    if kaisu >= 9 :
        print("引き分けです")
        break
    
    win = isEnd()
    if win:
        print("あなたの勝ちです")
        break
 
    myPlay()
    disp()
    
    win = isEnd()
    if win:
        disp()
        print("私の勝ちです")
        break
