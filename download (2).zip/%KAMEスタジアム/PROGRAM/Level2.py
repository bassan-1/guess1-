'''
 KAMEスタジアム　プレイヤー　Level2　作成者:ayax

'''
from pykame.pykame2 import *

First_angle = None # 最初の角度
fugou = 1    # X軸符号反転用
First = True # 初回呼出しフラグ　
KYORI = 21   # X,Y軸の差がこれ以上なら前進
LONG_KYORI = 250 # この距離以上ならアイテムを使う

#前進処理
def go(step,l):
    kyori = step
    # 距離が長いならスピードアイテムを使う
    if abs(l) > LONG_KYORI:
        item = get_speeditem()
        #アイテムはあるか
        if len(item) > 0:
            set_speeditem(item[0]) #最初に入っている一番速いアイテムを使う
            kyori = l # アイテムは次の命令のみ有効なので、全差分前進する
            
    forward(kyori)


def loop():
    global First,First_angle,fugou

    #　前進する距離(※差が100であっても2ずつ進んでいく)
    step_x = 2 
    step_y = 2
    
    if First: # 最初の呼出し
        if heading() == 0: # 角度が0なら左側に配置されている
            fugou = 1
            First_angle = 0
        else: # 右側に配置されている
            fugou = -1 # X軸の距離の符号を反転させる
            First_angle = 180
        First = False

            
    num = get_number() # 次の的番号を取得
    x,y = radar2(num)  # 自分と的との差を取得
    
    # キータイム中か？
    if is_keytime():    
        x2,y2 = position() # 自分の座標
        x3,y3 = get_keyposition() #　キーの座標
        x = x3 - x2 # キーまでの差を求める
        y = y3 - y2

    # 前進する距離の符号を差分に合わせる
    if x < 0:step_x = step_x * -1
    if y < 0:step_y = step_y * -1
    
    angle = heading() # 現在の角度を取得
    if angle == First_angle: # 最初の角度ならＸ軸の差分から前進
        if abs(x) >= KYORI:     # 差が衝突判定の距離より大きい時だけ前進
            go(step_x*fugou,x*fugou)
        else:                #Y軸の差分前進
            if abs(y) >= KYORI:
                setheading(90)
                go(step_y,y)
    else:
        if angle == 90:      # 90度ならY軸の差分から前進
            if abs(y) >= KYORI:
                go(step_y,y)
            else:
                if abs(x) >= KYORI:
                    setheading(First_angle)
                    go(step_x*fugou,x*fugou)

                
        
 