from pykame.pykame2 import * # 準備命令　必須

def loop(): # この関数名で呼び出される
    num = get_number() # 次の的番号を取得
    x,y = radar2(num) # 的との距離(差)を取得
    
    # キータイムが発生しているか？
    if is_keytime():
        #キータイム中は的よりキーを奪取！
        x2,y2 = position() # 自身の座標を取得
        x,y = get_keyposition() # キーの座標を取得
        x = x - x2 # X軸の差を求める
        y = y - y2 # Y軸の差をm止める

    kakudo = heading() # 自身の角度を取得
    fugou = 1   
    if kakudo == 180: # 180度向いているならX軸の差をマイナスとする
        fugou = -1
        
    forward(x*fugou) # X軸の差分進む
    setheading(90) # Y軸の差分進むため角度を90度へ
    forward(y) # Y軸の差分進む
    setheading(kakudo) # 元の角度(0度か180度へ戻す)
    
    