'''
 KAMEスタジアム　プレイヤー　Level1　作成者:ayax

'''
from pykame.pykame2 import *

fugou = 1      # X軸の符号反転用
First = True   # 最初の呼出しフラグ
Fist_angle = 0 # 最初の角度

def loop():
    global First,First_angle,fugou
    
    if First: # 最初の呼出し
        if heading() == 0: # 角度が0なら左側に配置されている
            fugou = 1
            First_angle = 0
        else: # 右側に配置されている
            fugou = -1 # X軸の距離の符号を反転させる
            First_angle = 180
        First = False
            
    num = get_number() # 次の的番号を取得
    x,y = radar2(num)  # 自分と的との差
    
    # キータイム中か？
    if is_keytime():    
        x2,y2 = position() # 自分の座標
        x3,y3 = get_keyposition() #　キーの座標
        x = x3 - x2 # キーまでの差を求める
        y = y3 - y2

    angle = heading() # 現在の角度を取得
    if angle == First_angle: # 最初の角度ならＸ軸の差分から前進
        if abs(x) >= 21:     # 差がこれ以上なら前進
            forward(x*fugou)
        else:                #Y軸の差分前進
            if abs(y) >= 21:
                setheading(90)
                forward(y)
    else:
        if angle == 90:      # 90度ならY軸の差分から前進
            if abs(y) >= 21:
                forward(y)
            else:
                if abs(x) >= 21:
                    setheading(First_angle)
                    forward(x*fugou)

                
        
 